using System;
class SVGModels {
   static void Main() {
      bool exit = false;
      //string canvas;
      List < object > canvas = new List < object > ();
      canvas.Add("<svg viewBox= \"0 0 300 100\" xmlns= \"http://www.w3.org/2000/svg\" >");

      Console.Clear();

      //loop until user selects exit
      while (exit == false) {

         Console.WriteLine("1) Create Circle");
         Console.WriteLine("2) Create Square");
         Console.WriteLine("3) Create Ellipse");
         Console.WriteLine("4) Create Line");
         Console.WriteLine("5) Create PolyLine");
         Console.WriteLine("6) Create Polygon");
         Console.WriteLine("7) Create Path");
         Console.WriteLine("8) Update Style");
         Console.WriteLine("9) Update SVG");
         Console.WriteLine("10) Swap Elements");
         Console.WriteLine("11) Delete Element");
         Console.WriteLine("12) Exit");
         Console.WriteLine();
         Console.WriteLine("---------------------");
         Console.WriteLine();

         int choice = int.Parse(Console.ReadLine());
         //switch statment to will create object based off choice var
         switch (choice) {
         case 1:
            canvas.Add(makeCircle());
            Console.WriteLine();

            break;

         case 2:
            canvas.Add(makeSquare());
            Console.WriteLine();
            break;

         case 3:
            canvas.Add(makeEllipse());
            Console.WriteLine();
            break;

         case 4:
            canvas.Add(makeLine());
            Console.WriteLine();
            break;

         case 5:
            canvas.Add(makePolyLine());
            Console.WriteLine();
            break;

         case 6:
            canvas.Add(makePolygon());
            Console.WriteLine();
            break;

         case 7:

            canvas.Add(makePath());
            Console.WriteLine();
            break;


        //Style update
         case 8:
            Console.WriteLine("Choose element to update.");
            for (int i = 1; i < canvas.Count; i++)
               Console.WriteLine(i + " - " + canvas[i]);

            int update2 = int.Parse(Console.ReadLine());
            updateStyle(canvas, update2);
            Console.WriteLine();
            break;


        //update svg
         case 9:
            Console.WriteLine("Choose element to update.");
            for (int i = 1; i < canvas.Count; i++)
               Console.WriteLine(i + " - " + canvas[i]);
            int update = int.Parse(Console.ReadLine());
            updateSVG(canvas, update);
            Console.WriteLine();
            break;

        //swap elements
         case 10:
            for (int i = 1; i < canvas.Count; i++)
               Console.WriteLine(i + " - " + canvas[i]);
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            swapElement(canvas, a, b);
            Console.WriteLine();
            break;


        //delete
         case 11:
            Console.WriteLine("Select element to Delete:");
            for (int i = 1; i < canvas.Count; i++)
               Console.WriteLine(i + " - " + canvas[i]);

            int delete = int.Parse(Console.ReadLine());
            if (delete != 0 | delete != canvas.Count)
               DeleteElement(canvas, delete);
            else
               Console.WriteLine("error, please try again");

            Console.WriteLine();
            break;

        //stops loop 
         case 12:
            exit = true;
            canvas.Add("</svg>");
            Console.WriteLine("Exited");
            break;
         }
      }

      //end
      //prints out canvas
      canvas.ForEach(Console.WriteLine);

      //turns canvas into a file
      createFile(canvas);
   }

   public static void swapElement(List < object > list, int a, int b) {
      object temp = list[a];
      list[a] = list[b];
      list[b] = temp;

   }

   public static void updateSVG(List < object > canvas, int a) {
      string old = canvas[a].ToString();
      if (old.Contains("circle")) {
         canvas[a] = makeCircle();
      } else if (old.Contains("polyline")) {
         canvas[a] = makePolyLine();
      } else if (old.Contains("rect")) {
         canvas[a] = makeSquare();
      } else if (old.Contains("ellipse")) {
         canvas[a] = makeEllipse();
      } else if (old.Contains("line")) {
         canvas[a] = makeLine();
      } else if (old.Contains("polygon")) {
         canvas[a] = makePolygon();
      } else if (old.Contains("path")) {
         canvas[a] = makePath();
      }

   }

   public static void updateStyle(List < object > list, int a) {
      string[] l = list[a].ToString().Split("stroke");

      Console.WriteLine();
      Console.Write("New stroke: ");
      string stroke = Console.ReadLine();

      Console.WriteLine();
      Console.Write("New fill: ");
      string fill = Console.ReadLine();

      Console.WriteLine();
      Console.Write("New width: ");
      string width = Console.ReadLine();

      //append new stroke and fill onto end of first part of the svg string

      list[a] = l[0] + " stroke=\"" + stroke + "\" " + "stroke-width = \"" + width + "\"" + " fill= \"" + fill + "\"" + "/>";

   }

   public static void DeleteElement(List < object > list, int a) {
      for (int i = a; i < list.Count; i++) {
         if ((i + 1) != list.Count)
            list[i] = list[i + 1];

         else
            list.RemoveAt(i);
      }

   }

   static void createFile(List < object > canvas) {
      String path = @"..\svgmodels\test.svg";

      if (File.Exists(path))
         File.Delete(path);

      using(StreamWriter fs = File.CreateText(path)) {

         canvas.ForEach(fs.WriteLine);
      }
   }
 // Abstract Shape class 
        public abstract class Shape
        {
            public override string ToString()
            {
                return "Shape!";
            }
        }

        // Circle Shape class
        public class Circle : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public int R { get; private set; }

            public Circle(int x, int y, int r)
            {
                X = x; Y = y; R = r;
            }

            public override string ToString()
            {
                return "<circle cx =" + "\"" + this.X + "\"" + " cy=" + "\"" + this.Y + "\"" + " r=" + "\"" + this.R +"\"" + " />";
            }
        }

         public class Square : Shape
        {
           

            public int X { get; private set; }
            public int Y { get; private set; }
            public int H { get; private set; }
            public int W { get; private set; }


            public Square(int x, int y, int h, int w)
            {
                X = x; Y = y; H = h; W = w;
            }

            
            public override string ToString()
            {
                return "<rect x =" + "\"" + this.X + "\"" + " y=" + "\"" + this.Y + "\"" + " width=" + "\"" + this.W +  "\"" +" height=" + "\"" + this.H +"\"" + " />";
                
            }
        }

         public class Ellipse : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public int RX { get; private set; }
            public int RY { get; private set; }


            public Ellipse(int x, int y, int rx, int ry)
            {
                X = x; Y = y; RX = rx; RY = ry;
            }

            public override string ToString()
            {
                return "<ellipse cx =" + "\"" + this.X + "\"" + " cy=" + "\"" + this.Y + "\"" + " rx=" + "\"" + this.RX +  "\"" +" ry=" + "\"" + this.RY +"\"" + " />";
                
            }
        }

         public class Line : Shape
        {

            public int X1 { get; private set; }
            public int Y1 { get; private set; }
            public int X2 { get; private set; }
            public int Y2 { get; private set; }


            public Line(int x1, int y1, int x2, int y2)
            {
                X1 = x1; Y1 = y1; X2 = x2; Y2 = y2;
            }

            public override string ToString()
            {
                return "<line x1 =" + "\"" + this.X1 + "\"" + " y1=" + "\"" + this.Y1 + "\"" + " x2=" + "\"" + this.X2 +  "\"" +" Y2=" + "\"" + this.Y2 +"\"" + " />";
                
            }
        }

         public class PolyLine : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public string POINTS { get; private set; }


            public PolyLine(int x, string points, int y)
            {
                X = x; POINTS = points; Y = y;;
            }

            public override string ToString()
            {
                return "<polyline points=\"" + this.X + "," + this.POINTS +" ," + this.Y + "\"" +" />";
                
            }
        }

        public class Polygon : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public string POINTS { get; private set; }


            public Polygon(int x, string points, int y)
            {
                X = x; POINTS = points; Y = y;;
            }

            public override string ToString()
            {
                return "<polygon points=\"" + this.X + "," + this.POINTS +" ," + this.Y +"\"" +" />";
                
            }
        }

         public class Path : Shape
        {

          
            public string POINTS { get; private set; }


            public Path(string points)
            {
                POINTS = points;
            }

            public override string ToString()
            {
                return "<path points=\"" + this.POINTS +"\"" + " />";
                
            }
        }

}