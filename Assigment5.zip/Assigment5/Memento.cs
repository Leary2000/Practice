using System;
    class App
    {
         public class ShapeFactory
        {

            public Shape generateShape(string TypeOfShape)
            {

                Random rnd = new Random();
                string RandomPath = "";

                for(int i = 0; i < rnd.Next(1,6); i++)
                {
                    RandomPath = RandomPath + (rnd.Next(10,100) + " " + rnd.Next(10,100) + ",");
                }
                
                switch(TypeOfShape)
                {
                    case "circle":
                    return new Circle(rnd.Next(1, 200), rnd.Next(1, 200), rnd.Next(1, 200));
                    break;

                    case "square":
                    return new Square(rnd.Next(1, 200), rnd.Next(1, 200), rnd.Next(1, 400), rnd.Next(1, 500));
                    break;

                    case "ellipse":
                    return new Ellipse(rnd.Next(1, 300), rnd.Next(1, 200), rnd.Next(1, 300), rnd.Next(1, 400));
                    break;

                    case "line":
                    return new Line(rnd.Next(1, 500), rnd.Next(1, 500), rnd.Next(1, 500), rnd.Next(1, 500));
                    break;  

                    case "polyline":
                    return new PolyLine(rnd.Next(1, 500), RandomPath, rnd.Next(1, 500));
                    break;                

                    case "polygon":
                    return new Polygon(rnd.Next(1, 200), RandomPath, rnd.Next(1, 300));
                    break;

                    case "path":
                    return new Path(RandomPath);
                    break;
                }
                throw new ArgumentException();

                }
                
            }


        static void Main ()
        {            
            Console.Clear();

            //will exit loop and quit program when set to true
            bool exit = false;

            List<object> canvas = new List<object>();
            Originator originator = new Originator();
            Caretaker caretaker = new Caretaker();

            canvas.Add("<svg viewBox= \"0 0 300 100\" xmlns= \"http://www.w3.org/2000/svg\" >");
            Console.WriteLine("Canvas created - use commands to add shapes to the canvas	");

            while(exit == false)
            {

            String[] choice = Console.ReadLine().Split(' ');
            switch (choice[0])
            {

            case "H":
            Console.WriteLine("Commands:");
            Console.WriteLine("       -H    Help");
            Console.WriteLine("       -A    Add <shape>");
            Console.WriteLine("       -U    Undo");
            Console.WriteLine("       -R    Redo");
            Console.WriteLine("       -D    Display canvas");
            Console.WriteLine("       -C    Clear canvas");
            Console.WriteLine("       -Q    Quit ");

            break;

            case "A":
            addShape(choice[1],canvas);
            //save current canvas

            originator.SetCanvas(canvas);
            //add memento of current canvas to the caretaker
            caretaker.add(originator.CreateMemento());

            //clear redo list when a new shape has been added
            caretaker.ClearRedo();
            break;

            case "U":
            try
            {
            caretaker.undo();
            canvas = caretaker.getMemento().getCanvas();
            }
            catch(Exception err)
            {
                //if Undo list is empty
                Console.WriteLine("Cannot Undo");
            }
            break;

            case "R":
            try{

            caretaker.redo();
            canvas = caretaker.getMemento().getCanvas();
            }
             catch(Exception err)
            {
               //if Redo list is empty
                Console.WriteLine("Cannot Redo");
            }
            break;

            case "C":
            canvas.Clear();
            //add svg line to cleared canvas
            canvas.Add("<svg viewBox= \"0 0 300 100\" xmlns= \"http://www.w3.org/2000/svg\" >");
            //save current canvas
            originator.SetCanvas(canvas);
            caretaker.add(originator.CreateMemento());
            break;

            case "D":
            canvas.ForEach(Console.WriteLine);
            Console.WriteLine("</svg>");
            break;

            case "Q":
            Console.WriteLine("Goodbye!");
            canvas = caretaker.getMemento().getCanvas();
            canvas.Add("</svg>");
            canvas.ForEach(Console.WriteLine);
            exit = true;
            break;

            }
           
        }

            //end
            //creates a file containing the final state of canvas
           createFile(canvas);
    }

   
        static void addShape(string shape,List<object> canvas)
        {
            ShapeFactory factory = new ShapeFactory();

            canvas.Add(factory.generateShape(shape.ToLower()));
            Console.WriteLine(shape.ToLower() + " added to canvas");
        }

        static void createFile(List<object> canvas)
        {
            String path = @"Canvas.svg";
          

            if(File.Exists(path))
            File.Delete(path);

             using (StreamWriter fs = File.CreateText(path))    
                {  

                canvas.ForEach(fs.WriteLine);
                }
        }

     
        // Abstract Shape class 
        public abstract class Shape
        {
            public override string ToString()
            {
                return "Shape!";
            }
        }

        // Circle Shape class
        public class Circle : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public int R { get; private set; }

            public Circle(int x, int y, int r)
            {
                X = x; Y = y; R = r;
            }

            public override string ToString()
            {
                return "<circle cx =" + "\"" + this.X + "\"" + " cy=" + "\"" + this.Y + "\"" + " r=" + "\"" + this.R +"\"" + " />";
            }
        }

         public class Square : Shape
        {
           

            public int X { get; private set; }
            public int Y { get; private set; }
            public int H { get; private set; }
            public int W { get; private set; }


            public Square(int x, int y, int h, int w)
            {
                X = x; Y = y; H = h; W = w;
            }

            
            public override string ToString()
            {
                return "<square cx =" + "\"" + this.X + "\"" + " cy=" + "\"" + this.Y + "\"" + " width=" + "\"" + this.W +  "\"" +" height=" + "\"" + this.H +"\"" + " />";
                
            }
        }

         public class Ellipse : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public int RX { get; private set; }
            public int RY { get; private set; }


            public Ellipse(int x, int y, int rx, int ry)
            {
                X = x; Y = y; RX = rx; RY = ry;
            }

            public override string ToString()
            {
                return "<ellipse cx =" + "\"" + this.X + "\"" + " cy=" + "\"" + this.Y + "\"" + " rx=" + "\"" + this.RX +  "\"" +" ry=" + "\"" + this.RY +"\"" + " />";
                
            }
        }

         public class Line : Shape
        {

            public int X1 { get; private set; }
            public int Y1 { get; private set; }
            public int X2 { get; private set; }
            public int Y2 { get; private set; }


            public Line(int x1, int y1, int x2, int y2)
            {
                X1 = x1; Y1 = y1; X2 = x2; Y2 = y2;
            }

            public override string ToString()
            {
                return "<line x1 =" + "\"" + this.X1 + "\"" + " y1=" + "\"" + this.Y1 + "\"" + " x2=" + "\"" + this.X2 +  "\"" +" Y2=" + "\"" + this.Y2 +"\"" + " />";
                
            }
        }

         public class PolyLine : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public string POINTS { get; private set; }


            public PolyLine(int x, string points, int y)
            {
                X = x; POINTS = points; Y = y;;
            }

            public override string ToString()
            {
                return "<polyline points=\"" + this.X + "," + this.POINTS +" ," + this.Y + "\"" +" />";
                
            }
        }

        public class Polygon : Shape
        {

            public int X { get; private set; }
            public int Y { get; private set; }
            public string POINTS { get; private set; }


            public Polygon(int x, string points, int y)
            {
                X = x; POINTS = points; Y = y;;
            }

            public override string ToString()
            {
                return "<polygon points=\"" + this.X + "," + this.POINTS +" ," + this.Y +"\"" +" />";
                
            }
        }

         public class Path : Shape
        {

          
            public string POINTS { get; private set; }


            public Path(string points)
            {
                POINTS = points;
            }

            public override string ToString()
            {
                return "<path points=\"" + this.POINTS +"\"" + " />";
                
            }
        }


        
        public  class Memento
        {
            private List<object> canvas = new List<object>();

            public Memento(List<object> canvas)
            {
                this.canvas = canvas;
            }

            public List<object> getCanvas()
            {
                return canvas;
            }

        }

        


        public class Originator
        {
            public List<object> canvas;

            public void SetCanvas(List<object> canvas)
            {
                this.canvas = new List<object>(canvas);
            }

            public List<object> GetCanvas()
            {
                return canvas;
            }

            public void setMemento(Memento memento)
            {
                canvas = memento.getCanvas();
            }

             public Memento CreateMemento()
            {
            return new Memento(canvas);
            }


        }



      
        class Caretaker
        {
            private List<Memento> Mementos = new List<Memento>();
            private List<Memento> MementosHistory = new List<Memento>();

            public void add(Memento CurrentMemento)
            {
            Mementos.Add(CurrentMemento);
            }
            public void ClearRedo()
            {
                MementosHistory.Clear();
            }


            public void undo()
            {
                int n = Mementos.Count - 1;
               
                MementosHistory.Add(Mementos[n]);
                Mementos.RemoveAt(n);
               
            }

            public void redo()
            {
                int n = MementosHistory.Count - 1;
                Mementos.Add(MementosHistory[n]);
                MementosHistory.RemoveAt(n);
                
            }

            public Memento getMemento()
            {
                return Mementos[Mementos.Count - 1];
            }
        }
}